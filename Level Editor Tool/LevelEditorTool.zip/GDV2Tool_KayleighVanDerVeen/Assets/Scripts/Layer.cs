﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class Layer : MonoBehaviour {

    public int id;
    public int priority;

    public Layer(int identity, int prio) {
		id = identity;
		priority = prio; 
	}
}
