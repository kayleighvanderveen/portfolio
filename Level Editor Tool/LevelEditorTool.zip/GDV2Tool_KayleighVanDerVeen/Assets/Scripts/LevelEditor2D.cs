﻿#if UNITY_EDITOR

using UnityEngine;
using UnityEditor;
using UnityEditorInternal;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public class LevelEditor2D : EditorWindow {

    #region Variables Init

    public GameObject curPrefab;                            // Current Tile
    public ReorderableList layerReord;                      // reorderable list that can be seen on the editor window
    public Layer currentLayer;                              //hold layer where objects will be placed
    public Tool lasTool;                                    //last tool (move/rotate/scale/rect) used before using maptool
    public List<Layer> layerlist = new List<Layer>();       //holds all the existing layers
    public static List<GameObject> allPrefabs;              //holds all prefabs that can be placed on the scene
    public static GameObject gizmoCursor, gizmoTile;        //gizmos that appear on the scene to help build the map
    public static SpriteRenderer gizmoTilesr;               //hold spriterenderer of the gizmotile
    public static LevelEditor2D instance;                      //instance of this script
    public static LevelEditor2D window;                        //holds reference to this window

    public Vector2 scrollPos;                               //instance of this script
    public Vector2 align;                                   //used to align prefabs that are not 1x1 to the grid
    public Vector2 mousePos;                                //mousePosition at all times
    public Vector3 beginPos;                                //first and final positions while dragging
    public Vector3 endPos;                                  //first and final positions while dragging

    public bool overWrite;                                  //bool that lets create in the same layer, an object above the other or not
    public bool snapping;                                   //lets you place an object not snapped to the grid
    public bool flipping;                                   //lets you place an object not snapped to the grid
    public bool areaDeletion;                               //controls when there will be an area deletion
    public bool areaInsertion;                              //control when there will be an area insertion
    public bool shiftwasPressed;                            //holds if shift was pressed and since then there wasn't a mouse up event
    public bool levelToolActive;                              //tells us if maptool is currently being used or not
    public bool showAlign = false;                          //Aligner GUI
    public bool showConsole = true;                         //true if you want to debug asset
    public static bool overWriteState;                      //bool that lets create in the same layer, an object above the other or not
    public static bool snappingState;                       //lets you place an object not snapped to the grid
    public static bool flippingState;                       //lets you place an object not snapped to the grid
    public static bool rotationState;                       //controls rotation of the object to place
    public static bool mouseDown;                           //hold if mouse is currently down
    public static bool selGridIntState;                     //item selected on the prefab selection grid

    public float rotation;                                  //controls rotation of the object to place
    public static float rotationState1;                     //controls rotation of the object to place

    public int controlID;                                   //used to make the whole tool work in some magic way
    public int selGridInt = 0;                              //item selected on the prefab selection grid
    public int alignId;                                     //used to align prefabs that are not 1x1 to the grid
    public static int selGridIntstatic = 0;                 //item selected on the prefab selection grid

    #endregion Variables Init

    #region Tool Init

    // Shortcut to open tool with Ctrl+M
    [MenuItem("Window/LevelEditor2D/Open Level Editor %m", false, 1)]
    public static void Init() {
        // Get existing open window or if none, make a new one:
        window = (LevelEditor2D)EditorWindow.GetWindow(typeof(LevelEditor2D));
        window.Show();

        window.minSize = new Vector2(200, 315);
        window.titleContent = new GUIContent("LevelEditor2D");
    }

    // Runs when the window is created
    public void OnEnable() {
        ShowLog("Enabled");

        alignId = 4;
        align = Vector2.zero;
        selGridInt = 0;
        instance = this;
        rotation = 0;
        overWrite = true;
        snapping = true;

        // Layer list
        layerReord = new ReorderableList(layerlist, typeof(Layer), true, true, true, true);
        layerReord.onAddCallback += AddLayer;
        layerReord.onRemoveCallback += RemoveLayer;
        layerReord.drawHeaderCallback += DrawHeader;
        layerReord.drawElementCallback += DrawElement;
        layerReord.onReorderCallback += OrganizeLayers;
        layerReord.onMouseUpCallback += SelectLayer;

        // Drag positions
        beginPos = Vector3.zero;
        endPos = Vector3.zero;

        LoadLayers();

        // If no layers, create one and use it
        if (layerlist.Count == 0) {
            AddLayer(layerReord);
            currentLayer = layerlist[0];
        }
        SceneView.onSceneGUIDelegate += SceneGUI;
    }

    #endregion Tool Init

    #region Prefabs
    public void LoadPrefabs() {
        if (allPrefabs == null)
            allPrefabs = new List<GameObject>();

        allPrefabs.Clear();

        // Adds all prefabs in resources folder
        var loadedObjects = Resources.LoadAll("");

        foreach (var loadedObject in loadedObjects) {
            if (loadedObject.GetType() == typeof(GameObject) && loadedObject.name != "TilePointerGizmo") {
                allPrefabs.Add(loadedObject as GameObject);
            }
        }
    }

    #endregion Prefabs

    #region Objects
    //Finds certain position
    public GameObject isObjectAt(Vector2 tilePos, Layer curLayer) {
        // Looks for object active layer
        for (int i = 0; i < curLayer.transform.childCount; i++) {
            GameObject g = curLayer.transform.GetChild(i).gameObject;
            ArtificialPosition artPos = g.GetComponent<ArtificialPosition>();

            if (artPos == null) {
                if (g.transform.localPosition == (Vector3)tilePos &&
                   (g.name != "gizmoCursor" && g.name != "gizmoTile")) {
                    if (g.transform.parent.parent == null) {
                        return g;
                    }
                }
            } else {
                // Objects that aren't 1x1
                if (artPos.position == tilePos && g.name != "gizmoCursor") {
                    return g;
                }
            }
        }
        return null;
    }
    #endregion Objects

    #region Closed Window
    // When window is closed
    public void OnDisable() {
        Tools.current = lasTool;

        // Destroy
        DestroyImmediate(GameObject.Find("gizmoTile"));
        DestroyImmediate(GameObject.Find("gizmoCursor"));

        // Clears 
        SceneView.onSceneGUIDelegate -= SceneGUI;
        layerReord.drawHeaderCallback -= DrawHeader;
        layerReord.drawElementCallback -= DrawElement;
        layerReord.onAddCallback -= AddLayer;
        layerReord.onRemoveCallback -= RemoveLayer;
        layerReord.onMouseUpCallback -= SelectLayer;
    }

    #endregion Closed Window

    #region Focus
    // Check if we are not on 
    public void OnLostFocus() {
    }

    // When the window is clicked
    public void OnFocus() {
        ActivateLevelTool();
        LoadPrefabs();

        // Find sprite renderer
        if (gizmoTilesr == null && gizmoTile != null)
            gizmoTilesr = gizmoTile.GetComponent<SpriteRenderer>();
    }

    #endregion Focus

    #region (De)Activate Tool 
    public void DeactivateLevelTool() {
        // If not selected, fetch last tool used
        if (Tools.current == Tool.None)
            Tools.current = lasTool;

        // Disable
        if (gizmoTile != null)
            gizmoTile.SetActive(false);

        if (gizmoCursor != null)
            gizmoCursor.SetActive(false);

        // Tool inactive
        levelToolActive = false;
    }

    public void ActivateLevelTool() {

        lasTool = Tools.current;
        Tools.current = Tool.None;

        // Activate
        if (gizmoTile != null)
            gizmoTile.SetActive(true);

        if (gizmoCursor != null)
            gizmoCursor.SetActive(true);

        // Tool active
        levelToolActive = true;
    }

    #endregion (De)Activate Tool

    #region GUI 
    // Updates with scene
    public void SceneGUI(SceneView sceneView) {

        Event e = Event.current;

        // Reactivate tool 
        if (e.type == EventType.keyDown && e.keyCode == KeyCode.M) {
            ActivateLevelTool();
        }

        // Tool ON/OFF 
        if (e.type == EventType.MouseUp && e.button == 1) {

            // On or off
            levelToolActive = !levelToolActive;

            if (levelToolActive == false) {
                DeactivateLevelTool();
            } else
                ActivateLevelTool();
        }

        // Tool ON/OFF
        if (e.type == EventType.keyUp && e.keyCode == KeyCode.Escape) {

            // On or off
            levelToolActive =! levelToolActive;

            if (levelToolActive == false) {
                DeactivateLevelTool();
            } else
                ActivateLevelTool();
        }

        // Get mouse position
        mousePos = HandleUtility.GUIPointToWorldRay(e.mousePosition).origin;

        // If user want to use other tools (E, R, T) 
        if (levelToolActive == true && Tools.current != Tool.None) {
            DeactivateLevelTool();
        }

        // Stop working 
        if (levelToolActive == false) {
            return;
        }

        // Sets ControlID 
        controlID = GUIUtility.GetControlID(FocusType.Passive);

        if (e.type == EventType.layout) {
            HandleUtility.AddDefaultControl(controlID);
        }

        switch (e.type) {
            // Checks if left click
            case EventType.mouseDown: {
                    if (e.button == 0) {
                        mouseDown = true;
                    }
                    break;
                }

            case EventType.mouseUp: {
                    if (e.button == 0) {
                        mouseDown = false;
                    }
                    break;
                }

            case EventType.keyDown: {

                    // Activate tool
                    if (e.keyCode == KeyCode.M) {
                        ActivateLevelTool();
                    }
                }
                break;
        }

        // Sets shift pressed 
        if (e.shift && mouseDown) {
            shiftwasPressed = true;
        }

        // Add tile on mouse down
        if (mouseDown && e.shift == false && areaInsertion == false) {

            // Prevents creating several gameobjects
            if (snapping == false)
                mouseDown = false;

            AddTile(gizmoCursor.transform.position, currentLayer);
        }

        // Add multiple tiles
        if (mouseDown && shiftwasPressed && areaInsertion == false && e.control == false) {

            areaInsertion = true;

            // Set new begin position
            if (areaDeletion == false)
                beginPos = gizmoCursor.transform.position;
            areaDeletion = false;

            ShowLog("Started Area Insertion");
        }

        // Starts AreaDeletion
        if (mouseDown && shiftwasPressed && areaDeletion == false && e.control == true) {
            areaDeletion = true;

            //if was not on areainsertion set new beginposition
            if (areaInsertion == false)
                beginPos = gizmoTile.transform.position;

            areaInsertion = false;
            ShowLog("Started Area Deletion");
        }

        // Draws Rectangle
        if (areaInsertion || areaDeletion) {

            DrawAreaRectangle();
            SceneView.RepaintAll();
        }

        //Deletes Elements
        if (mouseDown == false && areaDeletion == true && shiftwasPressed && e.control) {
            AreaDeletion();
            areaDeletion = false;
        }

        // Intantiates elements
        if (mouseDown == false && areaInsertion == true && shiftwasPressed && e.control == false) {
            AreaInsertion();
            areaInsertion = false;
        }

        // Remove tile 
        if (mouseDown && e.control && areaDeletion == false) {
            RemoveTile();
        }

        // Mouse up, shift not pressed
        if (mouseDown == false)
            shiftwasPressed = false;

        // Cursor position
        CursorUpdate();

        // Repaints editor window
        Repaint();
    }

    #endregion GUI

    // Rotates -90°
    [MenuItem("Window/LevelEditor2D/Rotate CW &r", false, 12)]
    public static void RotateGizmo() {
        if (instance == null)
            return;

        rotationState = true;
        rotationState1 -= 90;

        Undo.RecordObject(instance, "RO");
    }

    // Rotates +90° 
    [MenuItem("Window/LevelEditor2D/Rotate CCW #&r", false, 12)]
    public static void RotateCounterGizmo() {
        if (instance == null)
            return;

        rotationState = true;
        rotationState1 += 90;

        Undo.RecordObject(instance, "RO");
    }

    // Snapping
    [MenuItem("Window/LevelEditor2D/Snap &s", false, 24)]
    public static void ToggleSnapping() {
        if (instance == null)
            return;

        Undo.RegisterFullObjectHierarchyUndo(instance, "Snapping Shortcut");
        snappingState = true;
        EditorUtility.SetDirty(instance);
    }

    // Y flipping
    [MenuItem("Window/LevelEditor2D/Flip &d", false, 23)]
    public static void FlipSprite() {
        if (instance == null)
            return;

        flippingState = true;
        Undo.RecordObject(instance, "Flipping");
    }

    // Overwriting
    [MenuItem("Window/LevelEditor2D/OverWrite &a", false, 24)]
    public static void ToggleOverWrite() {
        if (instance == null)
            return;

        overWriteState = true;
        Undo.RecordObject(instance, "Overwrite");
    }

    // Rectangle area
    public void DrawAreaRectangle() {
        Vector4 area = GetAreaBounds();

        // Draw lines
        Handles.DrawLine(new Vector3(area[3] + 0.5f, area[0] + 0.5f, 0), new Vector3(area[1] - 0.5f, area[0] + 0.5f, 0)); // Top
        Handles.DrawLine(new Vector3(area[3] + 0.5f, area[2] - 0.5f, 0), new Vector3(area[1] - 0.5f, area[2] - 0.5f, 0)); // Down
        Handles.DrawLine(new Vector3(area[3] + 0.5f, area[0] + 0.5f, 0), new Vector3(area[3] + 0.5f, area[2] - 0.5f, 0)); // Left
        Handles.DrawLine(new Vector3(area[1] - 0.5f, area[0] + 0.5f, 0), new Vector3(area[1] - 0.5f, area[2] - 0.5f, 0)); // Right
    }

    // Area bounds
    public Vector4 GetAreaBounds() {
        Vector2 topLeft;
        Vector2 downRight;

        // Set end position for drag
        endPos = gizmoCursor.transform.position;

        // Finds
        topLeft.y = endPos.y > beginPos.y ? endPos.y : beginPos.y;
        topLeft.x = endPos.x < beginPos.x ? beginPos.x : endPos.x;
        downRight.y = endPos.y > beginPos.y ? beginPos.y : endPos.y;
        downRight.x = endPos.x < beginPos.x ? endPos.x : beginPos.x;

        return new Vector4(topLeft.y, downRight.x, downRight.y, topLeft.x);
    }

    public Vector3 OffsetWeirdTiles() {

        // Only works for one big object instead of parent of several objects
        if (gizmoTilesr != null && gizmoTilesr.sprite != null && (gizmoTilesr.sprite.bounds.extents.x != 0.5f || gizmoTilesr.sprite.bounds.extents.y != 0.5f))

            return new Vector3(-align.x * (gizmoTilesr.sprite.bounds.extents.x - 0.5f), align.y * (gizmoTilesr.sprite.bounds.extents.y - 0.5f), 0);

        return Vector3.zero;
    }

    // Delete gameobjects
    public void AreaDeletion() {
        Vector2 topLeft;
        Vector2 downRight;

        endPos = gizmoTile.transform.position;

        topLeft.y = endPos.y > beginPos.y ? endPos.y : beginPos.y;
        topLeft.x = endPos.x < beginPos.x ? beginPos.x : endPos.x;
        downRight.y = endPos.y > beginPos.y ? beginPos.y : endPos.y;
        downRight.x = endPos.x < beginPos.x ? endPos.x : beginPos.x;

        // Deletes object if there is one
        for (float y = downRight.y; y <= topLeft.y; y++) {
            for (float x = downRight.x; x <= topLeft.x; x++) {
                GameObject GOtoDelete = isObjectAt(new Vector3(x, y, 0), currentLayer);
                if (GOtoDelete != null) {
                    Undo.DestroyObjectImmediate(GOtoDelete);
                    DestroyImmediate(GOtoDelete);
                }
            }
        }
    }

    // Inserts area
    public void AreaInsertion() {
        Vector2 topLeft;
        Vector2 downRight;

        endPos = gizmoTile.transform.position;

        topLeft.y = endPos.y > beginPos.y ? endPos.y : beginPos.y;
        topLeft.x = endPos.x < beginPos.x ? beginPos.x : endPos.x;
        downRight.y = endPos.y > beginPos.y ? beginPos.y : endPos.y;
        downRight.x = endPos.x < beginPos.x ? endPos.x : beginPos.x;

        // Creates objects
        for (float y = downRight.y; y <= topLeft.y; y++) {
            for (float x = downRight.x; x <= topLeft.x; x++) {
                GameObject go = isObjectAt(new Vector3(x, y, 0), currentLayer);

                // Creates object if there is none
                if (go == null) {
                    InstantiateTile(new Vector3(x, y, 0), currentLayer);

                } else if (overWrite) {
                    Undo.DestroyObjectImmediate(go);
                    DestroyImmediate(go);
                    InstantiateTile(new Vector3(x, y), currentLayer);
                }
            }
        }
    }

    // If updated, reload layer if they are none
    public void OnInspectorUpdate() {
    }

    // Updates the gizmos 
    public void CursorUpdate() {
        // Find 
        if (gizmoCursor == null)
            gizmoCursor = GameObject.Find("gizmoCursor");

        if (gizmoTile == null)
            gizmoTile = GameObject.Find("gizmoTile");

        // If inactive, find
        if (gizmoTile == null || gizmoCursor == null) {
            Transform[] t = Resources.FindObjectsOfTypeAll<Transform>();

            foreach (var item in t) {
                if (item.name == "gizmoCursor") {
                    gizmoCursor = item.gameObject;
                    gizmoCursor.SetActive(true);
                }
                if (item.name == "gizmoTile") {
                    gizmoTile = item.gameObject;
                    gizmoTile.SetActive(true);

                }
            }
        }

        // Creates if none 
        if (gizmoCursor == null) {
            // Creates cursor
            GameObject pointer = (GameObject)Resources.Load("TilePointerGizmo", typeof(GameObject));
            if (pointer != null)
                gizmoCursor = (GameObject)Instantiate(pointer);
            else
                gizmoCursor = new GameObject();

            gizmoCursor.name = "gizmoCursor";
            gizmoCursor.hideFlags = HideFlags.HideInHierarchy;
            ShowLog("Cursor Created");
        }

        if (gizmoTile == null) {
            // If there are tiles, change
            if (allPrefabs != null && allPrefabs.Count > 0)
                ChangeGizmoTile();
            else
                // Create with default
                gizmoTile = new GameObject();

            gizmoTile.hideFlags = HideFlags.HideInHierarchy;
        }

        if (gizmoCursor != null) {
            // Check snapping and position cursor
            if (snapping) {
                Vector2 gizmoPos = Vector2.zero;

                if (mousePos.x - Mathf.Floor(mousePos.x) < 0.5f) {
                    gizmoPos.x = Mathf.Floor(mousePos.x) + 0.5f;
                } else if (Mathf.Ceil(mousePos.x) - mousePos.x < 0.5f) {
                    gizmoPos.x = Mathf.Ceil(mousePos.x) - 0.5f;
                }
                if (mousePos.y - Mathf.Floor(mousePos.y) < 0.5f) {
                    gizmoPos.y = Mathf.Floor(mousePos.y) + 0.5f;
                } else if (Mathf.Ceil(mousePos.y) - mousePos.y < 0.5f) {
                    gizmoPos.y = Mathf.Ceil(mousePos.y) - 0.5f;
                }

                // Set cursor and tile positions
                gizmoCursor.transform.position = gizmoPos;
                gizmoTile.transform.position = gizmoPos + (Vector2)gizmoTile.transform.InverseTransformVector(OffsetWeirdTiles());
            } else {
                // Set cursor and tile positions
                gizmoCursor.transform.position = mousePos;
                gizmoTile.transform.position = mousePos;
            }

            // Scale correctly
            if (curPrefab != null)
                gizmoTile.transform.localScale = curPrefab.transform.localScale;
        }
    }

    // Instantiate tile
    public GameObject InstantiateTile(Vector2 pos, Layer layer) {

        // Create tile if mouse over scene
        if (curPrefab == null || mouseOverWindow.ToString() != "(UnityEditor.SceneView)")
            return null;

        // Creates, rotates and parents object 
        GameObject metaTile = (GameObject)PrefabUtility.InstantiatePrefab(curPrefab);

        metaTile.transform.rotation = Quaternion.Euler(0, 0, rotation);
        metaTile.transform.SetParent(layer.transform);
        metaTile.transform.localPosition = (Vector3)pos + metaTile.transform.InverseTransformVector(OffsetWeirdTiles());

        // If uncommon shape
        if (metaTile.transform.localPosition != (Vector3)pos) {
            ArtificialPosition artPos = metaTile.AddComponent<ArtificialPosition>();
            artPos.position = pos;
            artPos.offset = artPos.position - (Vector2)metaTile.transform.position;
            artPos.layer = currentLayer;
        }

        // Get renderer
        SpriteRenderer sr = metaTile.GetComponent<SpriteRenderer>();

        // Set order in layer
        if (sr != null) {
            sr.sortingOrder = layerlist.Count - layerlist.IndexOf(currentLayer);

            if (gizmoTilesr != null)
                sr.flipY = gizmoTilesr.flipY;
        }
        Undo.RegisterCreatedObjectUndo(metaTile, "CreatedTile");
        return metaTile;
    }

    public void AddTile(Vector2 pos, Layer layer) {
        // Add tile if mouse over sceneview
        if (mouseOverWindow.ToString() != "(UnityEditor.SceneView)") {
            mouseDown = false;
            return;
        }
        // Check if object in position
        GameObject go = isObjectAt(pos, layer);

        // Creates/overwrites object
        if (go == null) {
            Undo.RegisterFullObjectHierarchyUndo(layer.transform, "Created go");
            InstantiateTile(pos, layer);
        } else if (overWrite) {
            Undo.RegisterFullObjectHierarchyUndo(layer.transform, "Created go");
            Undo.DestroyObjectImmediate(go);
            DestroyImmediate(go);
            InstantiateTile(pos, layer);
        }
    }

    // Deletes at certain location
    public void RemoveTile() {
        GameObject GOtoDelete = isObjectAt(new Vector3(gizmoCursor.transform.position.x, gizmoCursor.transform.position.y, 0), currentLayer);
        DestroyImmediate(GOtoDelete);
    }

    public void OnDestroy() {
        OnDisable();
    }

    // Turns childs into 'ghosts'
    public static void RecorrenciaSR(GameObject go) {
        if (go.GetComponent<SpriteRenderer>() != null) {
            Color c = go.GetComponent<SpriteRenderer>().color;
            c.a = 0.5f;
            go.GetComponent<SpriteRenderer>().color = c;
        }

        foreach (Transform t in go.transform) {
            RecorrenciaSR(t.gameObject);
        }
    }

    // Draw GUI
    public void OnGUI() {

        // Set button
        GUI.skin.button.alignment = TextAnchor.MiddleCenter;
        GUI.skin.button.imagePosition = ImagePosition.ImageAbove;
        EditorGUILayout.BeginVertical();

        // Scroll
        scrollPos = EditorGUILayout.BeginScrollView(scrollPos, false, false);

        // Label select prefab
        EditorGUILayout.LabelField("Select a prefab:");

        // If prefabs have been loaded
        if (allPrefabs != null && allPrefabs.Count > 0) {

            GUIContent[] content = new GUIContent[allPrefabs.Count];

            // Fill array with prefabs, name and image
            for (int i = 0; i < allPrefabs.Count; i++) {
                if (allPrefabs[i] != null && allPrefabs[i].name != "")
                    content[i] = new GUIContent(allPrefabs[i].name, AssetPreview.GetAssetPreview(allPrefabs[i]));

                if (content[i] == null)
                    content[i] = GUIContent.none;
            }
            EditorGUI.BeginChangeCheck();

            // Prevents error if objects are deleted
            while (selGridInt >= allPrefabs.Count)
                selGridInt--;

            // Creates selection grid
            int aselGridInt = GUILayout.SelectionGrid(selGridInt, content, 5,
                GUILayout.Height(50 * (Mathf.Ceil(allPrefabs.Count / (float)5))),
                GUILayout.Width(this.position.width - 30));

            if (EditorGUI.EndChangeCheck()) {
                Undo.RegisterCompleteObjectUndo(this, "GUI changed");
                selGridInt = aselGridInt;
                ChangeGizmoTile();
            }

            if (selGridIntState) {
                Undo.RegisterCompleteObjectUndo(this, "GUI changed");
                selGridInt = selGridIntstatic;
                selGridIntState = false;
                ChangeGizmoTile();
            } else {
                selGridIntstatic = aselGridInt;
                selGridInt = selGridIntstatic;

                if (gizmoTile != null)
                    gizmoTile.transform.rotation = Quaternion.Euler(0, 0, rotation);
            }
            curPrefab = allPrefabs[selGridInt];
        }
        EditorGUILayout.Space();

        // Snapping
        EditorGUI.BeginChangeCheck();
        float arotation = EditorGUILayout.FloatField("Rotation", rotation);

        // Overwrite
        bool aoverWrite = EditorGUILayout.Toggle(new GUIContent("Overwrite", "Overwrites the tile in the same layer and position"), overWrite);
        bool asnapping = EditorGUILayout.Toggle(new GUIContent("Snapping", "Snaps tiles to the grid"), snapping);
        bool aflipping = EditorGUILayout.Toggle(new GUIContent("Flipping", "Flips the object"), flipping);

        if (EditorGUI.EndChangeCheck()) {
            //Debug.Log ("Happened");
            Undo.RegisterCompleteObjectUndo(this, "GUI changed");
            rotation = arotation;

            // If GUI.changed
            snapping = asnapping;
            overWrite = aoverWrite;
            flipping = aflipping;

            if (gizmoTilesr != null)
                gizmoTilesr.flipY = flipping;

            gizmoTile.transform.rotation = Quaternion.Euler(0, 0, rotation);
        }
        if (snappingState == true) {
            snapping = !snapping;
            snappingState = false;
        }
        if (overWriteState == true) {
            overWrite = !overWrite;
            overWriteState = false;
        }
        if (flippingState == true) {
            flipping = !flipping;
            flippingState = false;

            if (gizmoTilesr != null)
                gizmoTilesr.flipY = flipping;
        }
        if (rotationState) {
            rotation = rotationState1;
            rotationState = false;
            if (gizmoTile != null)
                gizmoTile.transform.rotation = Quaternion.Euler(0, 0, rotation);
        } else {
            rotationState1 = arotation;
            rotation = arotation;
            if (gizmoTile != null)
                gizmoTile.transform.rotation = Quaternion.Euler(0, 0, rotation);
        }
        EditorGUILayout.Space();
        EditorGUI.BeginChangeCheck();

        // Show alignment
        showAlign = EditorGUILayout.Foldout(showAlign, new GUIContent("Alignment", "Used to align objects which size is not 1x1"), true);
        if (EditorGUI.EndChangeCheck()) {
        }
        // If fold-out is open
        if (showAlign) {
            EditorGUI.BeginChangeCheck();
            // Draw 3x3 grid 
            alignId = GUILayout.SelectionGrid(alignId, new string[9], 3, GUILayout.MaxHeight(40), GUILayout.MaxWidth(40));

            if (EditorGUI.EndChangeCheck()) {
                // New alignment
                align = alignId2Vec(alignId);
            }
        }

        // Cleans up layerlist
        for (int i = 0; i < layerlist.Count; i++) {
            if (layerlist[i] == null)
                layerlist.Remove(layerlist[i]);
        }

        // Prevent error if no current layer
        if (currentLayer == null && layerlist.Count > 0) {
            currentLayer = layerlist[0];
            layerReord.index = 0;
        }
        // Reorderable list
        layerReord.DoLayoutList();
        // Shows current layer
        if (currentLayer != null)
            EditorGUILayout.LabelField("Current Layer", currentLayer.name);

        // Shows prefab
        EditorGUI.BeginChangeCheck();
        curPrefab = (GameObject)EditorGUILayout.ObjectField("Current Prefab", curPrefab, typeof(GameObject), false);

        if (EditorGUI.EndChangeCheck()) {
            // If GUI.changed
            if (allPrefabs != null) {
                // Finds prefabs
                int activePre = allPrefabs.IndexOf(curPrefab);

                if (activePre > 0) {
                    selGridInt = activePre;
                }
            }
        }
        // Display current prefab
        Texture2D previewImage = AssetPreview.GetAssetPreview(curPrefab);
        GUILayout.Box(previewImage);
        EditorGUILayout.EndScrollView();
        EditorGUILayout.EndVertical();
        Repaint();
    }

    // Debug
    public void ShowLog(object msg) {
        if (showConsole) {
            Debug.Log(msg);
        }
    }

    // When hierarchy changes
    public void OnHierarchyChange() {
        LoadLayers();

        for (int i = 0; i < layerlist.Count; i++) {
            // Set priority 
            layerlist[i].priority = layerlist.Count - i;
            layerlist[i].transform.SetSiblingIndex(i);
        }

        if (Selection.activeGameObject != null) {
            Layer l = Selection.activeGameObject.GetComponent<Layer>();

            if (l != null && currentLayer != l) {
                currentLayer = l;
                layerReord.index = layerlist.IndexOf(l);
            }
        }
    }

    // Correct alignment
    public Vector2 alignId2Vec(int alignIndex) {
        Vector2 aux;
        aux.x = alignIndex % 3 - 1;
        aux.y = alignIndex / 3 - 1;
        ShowLog(aux);
        return aux;
    }

    // Change tile sprite
    public void ChangeGizmoTile() {
        if (gizmoTile != null) {
            Undo.DestroyObjectImmediate(gizmoTile);
        }
        if (allPrefabs != null && allPrefabs.Count > selGridInt && allPrefabs[selGridInt] != null) {
            gizmoTile = Instantiate(allPrefabs[selGridInt]) as GameObject;
            Undo.RegisterCreatedObjectUndo(gizmoTile, "CreatedTile");
        } else {
            gizmoTile = new GameObject();
            Undo.RegisterCreatedObjectUndo(gizmoTile, "CreatedTile");
        }

        rotationState1 = allPrefabs[selGridInt].transform.rotation.eulerAngles.z;
        rotationState = true;
        gizmoTile.name = "gizmoTile";
        gizmoTile.hideFlags = HideFlags.HideInHierarchy;

        if (gizmoTilesr == null)
            gizmoTilesr = gizmoTile.GetComponent<SpriteRenderer>();

        // Transparent
        RecorrenciaSR(gizmoTile);
    }

    #region Prefab shortcuts

    // Select objects

    [MenuItem("Window/LevelEditor2D/Select GameObject 1 _F1")]
    public static void Sel1() {
        if (instance == null)
            return;

        if (allPrefabs.Count > 0) {
            selGridIntstatic = 0;
            selGridIntState = true;
        }
    }

    [MenuItem("Window/LevelEditor2D/Select GameObject 2 _F2")]
    public static void Sel2() {
        if (instance == null)
            return;

        if (allPrefabs.Count > 1) {
            selGridIntstatic = 1;
            selGridIntState = true;
        }
    }

    [MenuItem("Window/LevelEditor2D/Select GameObject 3 _F3")]
    public static void Sel3() {
        if (instance == null)
            return;

        if (allPrefabs.Count > 2) {
            selGridIntstatic = 2;
            selGridIntState = true;
        }
    }

    [MenuItem("Window/LevelEditor2D/Select GameObject 4 _F4")]
    public static void Sel4() {
        if (instance == null)
            return;

        if (allPrefabs.Count > 3) {
            selGridIntstatic = 3;
            selGridIntState = true;
        }
    }

    [MenuItem("Window/LevelEditor2D/Select GameObject 5 _F5")]
    public static void Sel5() {
        if (instance == null)
            return;

        if (allPrefabs.Count > 4) {
            selGridIntstatic = 4;
            selGridIntState = true;
        }
    }

    #endregion Prefab shortcuts

    #region Layer functions

    /// Loads layers from scene
    public void LoadLayers() {
        // Clear the list
        if (layerlist != null)
            layerlist.Clear();

        // Find layers and add to list
        foreach (var item in Object.FindObjectsOfType<Layer>()) {
            layerlist.Add(item);
        }
        layerlist.Sort(delegate (Layer x, Layer y) {
            return x.transform.GetSiblingIndex() < y.transform.GetSiblingIndex() ? -1 : 1;
        });
    }

    // Reorder layers according to order in hierarchy
    public void ReorderLayers() {
        layerlist.Sort(delegate (Layer x, Layer y) {
            return x.transform.GetSiblingIndex() < y.transform.GetSiblingIndex() ? -1 : 1;
        });
        OrganizeLayers(layerReord);
    }

    // Add layer 
    private void AddLayer(ReorderableList list) {

        int val;
        int highestLayer = -1;

        // Find highest layer
        for (int i = 0; i < layerlist.Count; i++) {
            if (layerlist[i].name.Length > 6 && layerlist[i].name.Substring(0, 6).Contains("Layer")) {
                if (layerlist[i].name.Length > 5) {
                    // Perse layer number
                    val = int.Parse(layerlist[i].name.Substring(6));

                    if (val > highestLayer)
                        highestLayer = val;
                }
            }
        }

        highestLayer++;

        // Create layer
        ShowLog("Layer Creation");
        GameObject layerGo = new GameObject("Layer " + highestLayer);
        Undo.RegisterCreatedObjectUndo(layerGo, "Created layer");
        layerGo.AddComponent<Layer>();
        Layer layercmp = layerGo.GetComponent<Layer>();
        layercmp.id = 5;

        // Set current layer
        if (currentLayer != null) {
            layerlist.Insert(layerlist.IndexOf(currentLayer), layercmp);
            currentLayer = layercmp;
            layerReord.index = layerlist.IndexOf(currentLayer);
        } else {
            layerlist.Add(layercmp);
            layerReord.index = 0;
        }
        OrganizeLayers(list);
    }

    // Remove layer from list and hierarchy
    private void RemoveLayer(ReorderableList list) {
        Undo.DestroyObjectImmediate(layerlist[list.index].gameObject);
        layerlist.RemoveAt(list.index);
    }

    private void OrganizeLayers(ReorderableList list) {

        // Go through layers
        for (int i = 0; i < layerlist.Count; i++) {
            // Set priority
            layerlist[i].priority = layerlist.Count - i;
            layerlist[i].transform.SetSiblingIndex(i);

            // Set order
            for (int k = 0; k < layerlist[i].transform.childCount; k++) {
                SpriteRenderer sr = layerlist[i].transform.GetChild(k).GetComponent<SpriteRenderer>();

                if (sr != null)
                    sr.sortingOrder = layerlist.Count - i;
            }
            list.index = layerlist.IndexOf(currentLayer);
        }

        // Create layer if none
        if (layerlist.Count == 0) {
            AddLayer(layerReord);
            currentLayer = layerlist[0];
            layerReord.index = 0;
        }
    }

    private void SelectLayer(ReorderableList list) {

        currentLayer = layerlist[list.index];

        if (Selection.activeGameObject != null && Selection.activeGameObject != currentLayer.gameObject) {
            Layer l = Selection.activeGameObject.GetComponent<Layer>();

            ShowLog("SelectedLayer");

            if (l != null) {
                Selection.activeGameObject = currentLayer.gameObject;

                ShowLog(Selection.activeGameObject.name);
            }
        }
    }

    private void DrawHeader(Rect rect) {
        GUI.Label(rect, "Layers");
    }

    // Draw list element
    private void DrawElement(Rect rect, int index, bool active, bool focused) {

        Layer item = layerlist[index];

        // Prevents errors
        if (item == null)
            return;

        EditorGUI.BeginChangeCheck();
        string layername = item.name;
        // Editable name
        layername = EditorGUI.TextField(new Rect(rect.x, rect.y, 170, EditorGUIUtility.singleLineHeight), layername);

        if (EditorGUI.EndChangeCheck()) {
            Undo.RegisterCompleteObjectUndo(item.gameObject, "Layer Name Changed");
            item.gameObject.name = layername;
        }
        // Uneditable gameobject
        EditorGUI.ObjectField(new Rect(rect.x + 175, rect.y, rect.width - rect.width + 35, EditorGUIUtility.singleLineHeight), item.gameObject, typeof(GameObject), true);
    }

    #endregion Layer functions

}

#endif

