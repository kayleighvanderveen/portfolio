﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Script_MoveCanvas : MonoBehaviour {

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Space))
            MoveCanvas();
	}

    public void MoveCanvas()
    {
        Script_MoveUIElement[] scripts = transform.GetComponentsInChildren<Script_MoveUIElement>();
        foreach (Script_MoveUIElement s in scripts)
            s.MoveElement();
    }
}
