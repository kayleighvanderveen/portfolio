﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Script_Fade : MonoBehaviour {

    public bool fade = false;
    private Image img;

	// Use this for initialization
	void Start () {
        img = GetComponent<Image>();
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.F))
            fade = true;

        if (!fade)
            return;

        img.color = new Color(1, 1, 1, img.color.a + 0.03f);
	}
}
