﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Script_CanvasManager : MonoBehaviour {

    public Script_MoveCanvas currentCanvas;

	// Use this for initialization
	void Start () {
        StartCoroutine(InitialMove());
	}

    IEnumerator InitialMove()
    {
        yield return new WaitForSeconds(0.02f);
        currentCanvas.MoveCanvas();
    }

    public void SwitchCanvas(Script_MoveCanvas newCanvas)
    {
        StartCoroutine(SwitchCanvasCoroutine(newCanvas));
    }

    public IEnumerator SwitchCanvasCoroutine(Script_MoveCanvas newCanvas)
    {
        currentCanvas.MoveCanvas();
        currentCanvas.GetComponent<Canvas>().enabled = true;
        yield return new WaitForSeconds(0.4f);
        newCanvas.GetComponent<Canvas>().enabled = true;
        newCanvas.MoveCanvas();
        currentCanvas = newCanvas;
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
