﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Script_MoveUIElement : MonoBehaviour {

    public Vector2 offset;
    private Vector2 targetPosition, originalPosition, outsidePosition;
    public float smoothTime = 0.3f;

    private Vector3 velocity;
    
    // Use this for initialization
    void Start() {
        originalPosition = transform.localPosition;
        outsidePosition = new Vector2(transform.localPosition.x + offset.x, transform.localPosition.y + offset.y);

        transform.localPosition = outsidePosition;
        targetPosition = outsidePosition;
    }

    // Update is called once per frame
    void Update () {
        transform.localPosition = Vector3.SmoothDamp(transform.localPosition, targetPosition, ref velocity, smoothTime);
    }

    public void MoveElement()
    {
        if (targetPosition == outsidePosition)
            targetPosition = originalPosition;
        else
            targetPosition = outsidePosition;
    }
}
