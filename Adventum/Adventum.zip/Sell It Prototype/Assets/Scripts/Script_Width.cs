﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Script_Width : MonoBehaviour {

    private RectTransform rectT;
    private bool start = false;

	// Use this for initialization
	void Start () {
        rectT = GetComponent<RectTransform>();
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.E))
            start = true;

        if(rectT.sizeDelta.x < 1098 && start)
            rectT.sizeDelta = new Vector2(rectT.sizeDelta.x + 5, rectT.sizeDelta.y);
	}
}
